
class SortingAlgorithms {
    // Quick Sort
    public static void quickSort(int[] arr) {
        if (arr == null || arr.length == 0) {
            return;
        }
        quickSortHelper(arr, 0, arr.length - 1);
    }

    private static void quickSortHelper(int[] arr, int low, int high) {
        if (low < high) {
            int pivotIndex = partition(arr, low, high);
            quickSortHelper(arr, low, pivotIndex - 1);
            quickSortHelper(arr, pivotIndex + 1, high);
        }
    }

    private static int partition(int[] arr, int low, int high) {
        int pivot = arr[high];
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (arr[j] < pivot) {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;
        return i + 1;
    }

    // Bubble Sort
    public static void bubbleSort(int[] arr) {
        if (arr == null || arr.length == 0) {
            return;
        }
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    public static void main(String[] args) {
        int[] smallArray = new int[100];
        int[] largeArray = new int[10000];

        // Заполнение массивов элементами
        for (int i = 0; i < smallArray.length; i++) {
            smallArray[i] = (int) (Math.random() * 1000);
        }

        for (int i = 0; i < largeArray.length; i++) {
            largeArray[i] = (int) (Math.random() * 10000);
        }

        // Измерение времени выполнения Quick Sort для небольшого массива
        long startTime = System.nanoTime();
        quickSort(smallArray);
        long endTime = System.nanoTime();
        long durationQuickSortSmall = endTime - startTime;

        // Измерение времени выполнения Quick Sort для крупного массива
        startTime = System.nanoTime();
        quickSort(largeArray);
        endTime = System.nanoTime();
        long durationQuickSortLarge = endTime - startTime;

        // Измерение времени выполнения Bubble Sort для небольшого массива
        startTime = System.nanoTime();
        bubbleSort(smallArray);
        endTime = System.nanoTime();
        long durationBubbleSortSmall = endTime - startTime;

        // Измерение времени выполнения Bubble Sort для крупного массива
        startTime = System.nanoTime();
        bubbleSort(largeArray);
        endTime = System.nanoTime();
        long durationBubbleSortLarge = endTime - startTime;

        // Вывод результатов
        System.out.println("Quick Sort small: " + durationQuickSortSmall + " ns");
        System.out.println("Quick Sort big: " + durationQuickSortLarge + " ns");
        System.out.println("Bubble Sort small: " + durationBubbleSortSmall + " ns");
        System.out.println("Bubble Sort big: " + durationBubbleSortLarge + " ns");
    }
}